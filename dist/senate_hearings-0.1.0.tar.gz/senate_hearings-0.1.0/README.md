## URLs
https://www.govinfo.gov/browse/committee

## Categorical variables
Congress num: 112th, 117th. These are broken down by year
Commitee: Armed Services, Foreign relations
Year: possibly use the congress number though. They are broken down into years by congress

## Data Frame layout(hesitant)

Index - Congress - Commitee - Month - Day - Year - Subcommitee - Topic/Title - Text

## \robots.txt

#
# robots.txt
#

User-agent: *
# CSS, JS, Images
Allow: /core/*.css$
Allow: /core/*.css?
Allow: /core/*.js$
Allow: /core/*.js?
Allow: /core/*.gif
Allow: /core/*.jpg
Allow: /core/*.jpeg
Allow: /core/*.png
Allow: /core/*.svg
Allow: /profiles/*.css$
Allow: /profiles/*.css?
Allow: /profiles/*.js$
Allow: /profiles/*.js?
Allow: /profiles/*.gif
Allow: /profiles/*.jpg
Allow: /profiles/*.jpeg
Allow: /profiles/*.png
Allow: /profiles/*.svg
# Directories
Disallow: /core/
Disallow: /profiles/
# Paths (clean URLs)
Disallow: /admin/
Disallow: /comment/reply/
Disallow: /filter/tips
Disallow: /node/add/
Disallow: /search/
Disallow: /user/register
Disallow: /user/password
Disallow: /user/login
Disallow: /user/logout
Disallow: /media/oembed
Disallow: /*/media/oembed
# Paths (no clean URLs)
Disallow: /index.php/admin/
Disallow: /index.php/comment/reply/
Disallow: /index.php/filter/tips
Disallow: /index.php/node/add/
Disallow: /index.php/search/
Disallow: /index.php/user/password
Disallow: /index.php/user/register
Disallow: /index.php/user/login
Disallow: /index.php/user/logout
Disallow: /index.php/media/oembed
Disallow: /index.php/*/media/oembed

Sitemap: https://www.govinfo.gov/sitemap/sitemap.xml
Sitemap: https://www.govinfo.gov/sitemap/BILLS_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/BUDGET_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CCAL_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CDIR_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CDOC_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CFR_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CHRG_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CMR_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/COMPS_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CPRT_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CRECB_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CREC_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CRI_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CRPT_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/CZIC_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/DCPD_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/ECONI_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/ERIC_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/ERP_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/FR_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/GAOREPORTS_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/GOVMAN_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/GOVPUB_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/GPO_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/HJOURNAL_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/HMAN_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/HOB_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/LSA_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/PAI_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/PLAW_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/PPP_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/SERIALSET_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/SMAN_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/STATUTE_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/USCODE_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/USCOURTS_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/USREPORTS_sitemap_index.xml
Sitemap: https://www.govinfo.gov/sitemap/WCPD_sitemap_index.xml

# Bulkdata sitemaps
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/BILLSTATUS/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/BILLSUM/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/BILLS/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/CBD/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/CFR/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/ECFR/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/FR/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/GOVMAN/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/HMAN/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/PAI/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/PPP/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/PLAW/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/SCD/sitemapindex.xml
Sitemap: https://www.govinfo.gov/sitemap/bulkdata/STATUTE/sitemapindex.xml